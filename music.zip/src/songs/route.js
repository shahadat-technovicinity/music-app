import express from 'express';
import { SongController } from './controller.js';
import { authMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();
// router.get('/', SongController.getAllSongs);
// router.get('/new', SongController.getNewReleases);
// router.get('/trending', SongController.getTrendingSongs);
// router.get('/recommended', authMiddleware, SongController.getRecommendedSongs);
// router.get('/:id', SongController.getSongById);

// router.post('/', authMiddleware, SongController.createSong);
// router.put('/:id', authMiddleware, SongController.updateSong);
// router.delete('/:id', authMiddleware, SongController.deleteSong);

export {router as SongRouter};
