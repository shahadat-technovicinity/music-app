import mongoose from 'mongoose';
const { Schema } = mongoose;
const songSchema = new Schema({
    title: String,
    artist: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    coverImage: String,
    audioUrl: String,
    genre: String,
    duration: Number,
    releaseDate: Date,
    playCount: {
      type: Number,
      default: 0
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    createdAt: {
      type: Date,
      default: Date.now
    },
    updatedAt: {
      type: Date,
      default: Date.now
    }
  });
  
  const Song = mongoose.model('Song', songSchema);
  export { Song };