import { Song } from './model.js';
import { User } from '../users/model.js';

const SongController = {
    getNewReleases: async (req, res) => {
    try {
        const recent = new Date();
        recent.setDate(recent.getDate() - 14);
        const songs = await Song.find({ releaseDate: { $gte: recent } }).sort({ releaseDate: -1 });
        res.status(200).json(songs);
    } catch (err) {
        res.status(500).json({ message: 'Failed to get new releases', error: err.message });
    }
    },

    getTrendingSongs: async (req, res) => {
    try {
        const songs = await Song.find().sort({ playCount: -1 }).limit(10);
        res.status(200).json(songs);
    } catch (err) {
        res.status(500).json({ message: 'Failed to get trending songs', error: err.message });
    }
    },

    getRecommendedSongs: async (req, res) => {
    try {
        const user = await User.findById(req.user.id);
        const songs = await Song.find({ genre: { $in: user.genres } }).limit(10);
        res.status(200).json(songs);
    } catch (err) {
        res.status(500).json({ message: 'Failed to get recommended songs', error: err.message });
    }
    },

    getAllSongs: async (req, res) => {
    try {
        const songs = await Song.find();
        res.status(200).json(songs);
    } catch (err) {
        res.status(500).json({ message: 'Failed to get songs', error: err.message });
    }
    },

    getSongById: async (req, res) => {
    try {
        const song = await Song.findById(req.params.id);
        if (!song) return res.status(404).json({ message: 'Song not found' });
        res.status(200).json(song);
    } catch (err) {
        res.status(500).json({ message: 'Failed to get song', error: err.message });
    }
    },
}
export {SongController};