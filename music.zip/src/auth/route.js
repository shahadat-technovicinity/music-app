import express from 'express';
import {registerController, loginController,changePasswordController,forgetPasswordController,verifyOtpController,resetPasswordController, refreshTokenController,logoutController} from './controller.js';
import {upload} from '../middleware/uploadFile.js';
const router = express.Router();

// register route
router.post('/register',upload.single("photo"), registerController);

// login route
router.post('/login', loginController);
router.post('/change-password', changePasswordController);

// forgot password route
router.post('/forget-password',forgetPasswordController);
router.post('/forget-password/verify-otp', verifyOtpController);
router.post('/reset-password', resetPasswordController);

// refresh token route
router.post('/refresh-token', refreshTokenController);

// logout route
router.post('/logout', logoutController);
export {router as AuthRouter};