import e from 'express';
import { Follow } from './model.js';

const FollowController = {
followUser: async (req, res) => {
   try{
    const { id: followingId } = req.params; // User to follow
    const followerId = req.user.id; // Current logged-in user

    if (followerId.toString() === followingId) {
        return res.stataus(400).json({
            success: false,
            message: "You cannot follow yourself."
        })
    }

    const existingFollow = await Follow.findOne({ follower: followerId, following: followingId });
    if (existingFollow) {
        return res.status(400).json({
            success: false,
            message: "You are already following this user."
        });
    }

    const follow = new Follow({ follower: followerId, following: followingId });
    await follow.save();

    res.status(200).json({
        success: true,
        message: "User followed successfully.",
        data: follow
    });
   }catch (error) {
        console.error('Error following user:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error',
        });
    }
   
},
unfollowUser: async (req, res) => {
   try{
    const { id: followingId } = req.params; // User to unfollow
    const followerId = req.user.id; // Current logged-in user

    const follow = await Follow.findOneAndDelete({ follower: followerId, following: followingId });
    if (!follow) {
        return res.status(404).json({
            success: false,
            message: "You are not following this user."
        });
    }

    res.status(200).json({
        success: true,
        message: "User unfollowed successfully.",
        data: follow
    });
   }catch (error) {
        console.error('Error unfollowing user:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error',
        });
    }
},

getFollowers: async (req, res) => {
    try{
        const userId = req.user.id; // Current logged-in user
    const followers = await Follow.find({ following: userId }).populate('follower', 'name email profilePicture');
    res.status(200).json({
        success: true,
        message: "Followers retrieved successfully.",
        data: followers
    })
    }catch (error) {
        console.error('Error retrieving followers:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error',
        });
    }
},

getFollowing: async (req, res) => {
    try{
        const userId = req.user.id; // Current logged-in user
        const following = await Follow.find({ follower: userId }).populate('following', 'name email profilePicture');
        res.status(200).json({
            success: true,
            message: "Following users retrieved successfully.",
            data: following
        })
    }catch (error) {
        console.error('Error retrieving following users:', error);
        return res.status(500).json({
            success: false,
            message: 'Internal server error',
        });
    }
},

};

export {FollowController};