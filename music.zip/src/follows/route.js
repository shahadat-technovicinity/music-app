import express from 'express';
import { FollowController } from './controller.js';
import { authMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();

// router.post('/:id', authMiddleware, FollowController.followUser);
// router.delete('/:id', authMiddleware, FollowController.unfollowUser);
// router.get('/:id/followers', authMiddleware, FollowController.getFollowers);
// router.get('/:id/following', authMiddleware, FollowController.getFollowing);

export { router as FollowRouter };