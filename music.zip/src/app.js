import express from 'express';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import {AuthRouter} from './auth/route.js';
import {UserRouter} from './users/route.js';
import {AlbumRouter} from './albums/route.js';
import {MerchandiseRouter} from './merchandises/route.js';
import {FollowRouter} from './follows/route.js';
import {PostRouter} from './posts/route.js';
import {PreferencesRouter} from './preferences/route.js';
import { SongRouter } from './songs/route.js';
const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


// for cookies
app.use(cookieParser());

// log requests
app.use(morgan("dev"));

// Routes
app.get('/', (req, res) => {
  res.send('Hello from music app server!');
});

app.use('/api/v1/auth', AuthRouter);
app.use('/api/v1/users', UserRouter);
app.use('/api/v1/albums', AlbumRouter);
app.use('/api/v1/merchandises', MerchandiseRouter);
app.use('/api/v1/follows', FollowRouter);
app.use('/api/v1/posts', PostRouter);
app.use('/api/v1/preferences', PreferencesRouter);
app.use('/api/v1/songs', SongRouter);


export { app };