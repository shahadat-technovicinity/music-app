import { Post } from './model.js'; // Assuming Post model exists
import { User } from '../users/model.js'; // Assuming User model exists

const PostController = {
    createPost: async (req, res) => {
        try {
            const { title, description, imageUrl } = req.body;
            const userId = req.user.id; // Current logged-in user

            const newPost = new Post({
                title,
                description,
                imageUrl,
                userId,
            });

            await newPost.save();

            res.status(201).json({
                success: true,
                message: "Post created successfully.",
                data: newPost,
            });
        } catch (error) {
            console.error('Error creating post:', error);
            res.status(500).json({
                success: false,
                message: 'Internal server error',
            });
        }
    },

    getAllPosts: async (req, res) => {
        try {
            const posts = await Post.find().populate('userId', 'name email profile_picture');
            res.status(200).json({
                success: true,
                message: "Posts retrieved successfully.",
                data: posts,
            });
        } catch (error) {
            console.error('Error retrieving posts:', error);
            res.status(500).json({
                success: false,
                message: 'Internal server error',
            });
        }
    },

    getPostById: async (req, res) => {
        try {
            const { id } = req.params;
            const post = await Post.findById(id).populate('userId', 'name email profile_picture');

            if (!post) {
                return res.status(404).json({
                    success: false,
                    message: 'Post not found',
                });
            }

            res.status(200).json({
                success: true,
                message: "Post retrieved successfully.",
                data: post,
            });
        } catch (error) {
            console.error('Error retrieving post:', error);
            res.status(500).json({
                success: false,
                message: 'Internal server error',
            });
        }
    },

    updatePost: async (req, res) => {
        try {
            const { id } = req.params;
            const { title, description, imageUrl } = req.body;

            const updatedPost = await Post.findByIdAndUpdate(
                id,
                { title, description, imageUrl },
                { new: true }
            );

            if (!updatedPost) {
                return res.status(404).json({
                    success: false,
                    message: 'Post not found',
                });
            }

            res.status(200).json({
                success: true,
                message: "Post updated successfully.",
                data: updatedPost,
            });
        } catch (error) {
            console.error('Error updating post:', error);
            res.status(500).json({
                success: false,
                message: 'Internal server error',
            });
        }
    },

    deletePost: async (req, res) => {
        try {
            const { id } = req.params;

            const deletedPost = await Post.findByIdAndDelete(id);

            if (!deletedPost) {
                return res.status(404).json({
                    success: false,
                    message: 'Post not found',
                });
            }

            res.status(200).json({
                success: true,
                message: "Post deleted successfully.",
            });
        } catch (error) {
            console.error('Error deleting post:', error);
            res.status(500).json({
                success: false,
                message: 'Internal server error',
            });
        }
    },

    likePost: async (req, res) => {
        try {
            const { id } = req.params;
            const userId = req.user.id;

            const post = await Post.findById(id);

            if (!post) {
                return res.status(404).json({
                    success: false,
                    message: 'Post not found',
                });
            }

            if (post.likes.includes(userId)) {
                return res.status(400).json({
                    success: false,
                    message: 'You already liked this post',
                });
            }

            post.likes.push(userId);
            await post.save();

            res.status(200).json({
                success: true,
                message: "Post liked successfully.",
                data: post,
            });
        } catch (error) {
            console.error('Error liking post:', error);
            res.status(500).json({
                success: false,
                message: 'Internal server error',
            });
        }
    },

    unlikePost: async (req, res) => {
        try {
            const { id } = req.params;
            const userId = req.user.id;

            const post = await Post.findById(id);

            if (!post) {
                return res.status(404).json({
                    success: false,
                    message: 'Post not found',
                });
            }

            if (!post.likes.includes(userId)) {
                return res.status(400).json({
                    success: false,
                    message: 'You have not liked this post',
                });
            }

            post.likes = post.likes.filter((like) => like.toString() !== userId);
            await post.save();

            res.status(200).json({
                success: true,
                message: "Post unliked successfully.",
                data: post,
            });
        } catch (error) {
            console.error('Error unliking post:', error);
            res.status(500).json({
                success: false,
                message: 'Internal server error',
            });
        }
    },

    commentOnPost: async (req, res) => {
        try {
            const { id } = req.params;
            const { comment } = req.body;
            const userId = req.user.id;

            const post = await Post.findById(id);

            if (!post) {
                return res.status(404).json({
                    success: false,
                    message: 'Post not found',
                });
            }

            post.comments.push({ userId, comment });
            await post.save();

            res.status(201).json({
                success: true,
                message: "Comment added successfully.",
                data: post,
            });
        } catch (error) {
            console.error('Error commenting on post:', error);
            res.status(500).json({
                success: false,
                message: 'Internal server error',
            });
        }
    },

    getAllComments: async (req, res) => {
        try {
            const { id } = req.params;

            const post = await Post.findById(id).populate('comments.userId', 'name email profile_picture');

            if (!post) {
                return res.status(404).json({
                    success: false,
                    message: 'Post not found',
                });
            }

            res.status(200).json({
                success: true,
                message: "Comments retrieved successfully.",
                data: post.comments,
            });
        } catch (error) {
            console.error('Error retrieving comments:', error);
            res.status(500).json({
                success: false,
                message: 'Internal server error',
            });
        }
    },

    sharePost: async (req, res) => {
        try {
            const { id } = req.params;
            const userId = req.user.id;

            const post = await Post.findById(id);

            if (!post) {
                return res.status(404).json({
                    success: false,
                    message: 'Post not found',
                });
            }

            post.shares.push(userId);
            await post.save();

            res.status(200).json({
                success: true,
                message: "Post shared successfully.",
                data: post,
            });
        } catch (error) {
            console.error('Error sharing post:', error);
            res.status(500).json({
                success: false,
                message: 'Internal server error',
            });
        }
    },
};

export {PostController};